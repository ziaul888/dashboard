import React from 'react'
import "./sidebar.scss"
import AccountBoxOutlinedIcon from '@mui/icons-material/AccountBoxOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';
import EngineeringIcon from '@mui/icons-material/Engineering';
import SystemUpdateAltOutlinedIcon from '@mui/icons-material/SystemUpdateAltOutlined';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import BarChartIcon from '@mui/icons-material/BarChart';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import DashboardIcon from '@mui/icons-material/Dashboard';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import BorderStyleIcon from '@mui/icons-material/BorderStyle';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
const Sidebar = () => {
    return (
        <div className='sidebar'>
            <div className='top'>
                <span className='logo'>logo</span>

            </div>
            <hr />
            <div className='center'>
                <ul>
                <p className="title">Main</p>
                    <li>
                        <DashboardIcon />
                        <span>dashborad </span>
                    </li>
                    <li>
                    <p className="title">Lists</p>
                   <PersonOutlineOutlinedIcon/>
                        <span>user</span>

                    </li>
                    <li>
                        <Inventory2Icon />
                        <span>products</span>
                    </li>
                    <li>
                        <BorderStyleIcon/>
                        <span> order </span>

                    </li>
                    <li>
                        <LocalShippingIcon />
                        <span>
                         Delivery
                        </span>

                    </li>
                    <p className="title">UseFull</p>
                    <li>
                        <BarChartIcon/>
                        <span>
                            status
                        </span>

                    </li>
                    <li>
                        <NotificationsActiveIcon />
                        <span>
                            Notification
                        </span>

                    </li>
                    <p className="title">Service</p>
                    <li>
                        <SystemUpdateAltOutlinedIcon />
                        <span>
                            System
                        </span>

                    </li>
                    <li>
                        <EngineeringIcon />
                        <span>
                            logs
                        </span>

                    </li>
                    <li>
                        <AdminPanelSettingsOutlinedIcon />
                        <span>
                            setting
                        </span>

                    </li>
                    <p className="title">User</p>
                    <li>
                    <AccountBoxOutlinedIcon />
                    <span>Profile</span>
                </li>
                    <li>
                    <LogoutOutlinedIcon />
                    <span>Logout</span>
                </li>
                </ul>
            </div>
            <div className='color-block'>
                color option</div>
        </div>
    )
}

export default Sidebar